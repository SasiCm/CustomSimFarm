using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StoreManager : MonoBehaviour
{
    public GameObject plantItem;
    List<PlantObject> PlantObjects = new List<PlantObject>();
    private void Awake()
    {
        // Assets/Resources/Plants
        var loadPLants = Resources.LoadAll("Plants", typeof(PlantObject));
        foreach (var plant in loadPLants)
        {
            PlantObjects.Add((PlantObject)plant);
        }
        PlantObjects.Sort(SortByPrice);

        foreach (var plant in PlantObjects)
        {
           PlantItem newPlant = Instantiate(plantItem, transform).GetComponent<PlantItem>();
           newPlant.plant = (PlantObject)plant;
        }
    }

    int SortByPrice(PlantObject plantObject1, PlantObject plantObject2)
    {
        return plantObject1.buyPrice.CompareTo(plantObject2.buyPrice);
    }
    
    int SortByTime(PlantObject plantObject1, PlantObject plantObject2)
    {
        return plantObject1.timeBtwStages.CompareTo(plantObject2.timeBtwStages);
    }

}
